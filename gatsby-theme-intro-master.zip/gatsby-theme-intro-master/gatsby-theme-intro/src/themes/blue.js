module.exports = {
  'back': '#d0dde3',
  'front': '#1f1f1f',
  'lead': '#0abae6',
  'lead-text': '#ffffff',
  'line': '#a9bfc9',
  'skill-1': '#073eb9',
  'skill-2': '#1f58da',
  'skill-3': '#4073e8',
};