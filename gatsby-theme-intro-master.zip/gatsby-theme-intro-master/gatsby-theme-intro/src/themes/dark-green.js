module.exports = {
  'back': '#161b23',
  'front': '#9dadc5',
  'lead': '#91e12a',
  'lead-text': '#161b23',
  'line': '#28303c',
  'skill-1': '#25a55f',
  'skill-2': '#9bdf46',
  'skill-3': '#e9f679',
};