module.exports = {
  'back': '#1c1f25',
  'front': '#a7aeb8',
  'lead': '#556e94',
  'lead-text': '#f7f7f7',
  'line': '#23272e',
  'skill-1': '#e14594',
  'skill-2': '#7045af',
  'skill-3': '#2b3595',
};