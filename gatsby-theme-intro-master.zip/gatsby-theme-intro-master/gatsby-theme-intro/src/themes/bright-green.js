module.exports = {
  'back': '#edf1f6',
  'front': '#050608',
  'lead': '#1de088',
  'lead-text': '#ffffff',
  'line': '#cfd6df',
  'skill-1': '#1e2127',
  'skill-2': '#393e46',
  'skill-3': '#5c636e',
};