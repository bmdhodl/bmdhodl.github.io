module.exports = {
  'back': '#eeeeed',
  'front': '#393e46',
  'lead': '#f8b500',
  'lead-text': '#f7f7f7',
  'line': '#d5d5ce',
  'skill-1': '#1e2127',
  'skill-2': '#393e46',
  'skill-3': '#5c636e',
};