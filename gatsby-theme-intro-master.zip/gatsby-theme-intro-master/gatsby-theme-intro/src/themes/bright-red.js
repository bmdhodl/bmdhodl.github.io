module.exports = {
  'back': '#f0f0f0',
  'front': '#050608',
  'lead': '#ec2e17',
  'lead-text': '#ffffff',
  'line': '#dedede',
  'skill-1': '#1e2127',
  'skill-2': '#393e46',
  'skill-3': '#5c636e',
};