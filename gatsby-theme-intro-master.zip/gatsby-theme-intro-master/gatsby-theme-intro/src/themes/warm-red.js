module.exports = {
  'back': '#e4e0e1',
  'front': '#4b3c3e',
  'lead': '#ce2f3a',
  'lead-text': '#ffffff',
  'line': '#d3c6ca',
  'skill-1': '#ce2f3a',
  'skill-2': '#2d3c4d',
  'skill-3': '#f0ba0d',
};