module.exports = {
  'back': '#222831',
  'front': '#bdc5d0',
  'lead': '#125fec',
  'lead-text': '#eeeeee',
  'line': '#29303a',
  'skill-1': '#0077b5',
  'skill-2': '#00adb5',
  'skill-3': '#854af0',
};