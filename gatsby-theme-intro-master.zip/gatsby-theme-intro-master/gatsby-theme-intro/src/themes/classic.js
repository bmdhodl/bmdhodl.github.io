module.exports = {
  'back': '#e8eaef',
  'front': '#1f1f1f',
  'lead': '#eee841',
  'lead-text': '#1f1f1f',
  'line': '#cfd1d7',
  'skill-1': '#9079db',
  'skill-2': '#e58b5f',
  'skill-3': '#3ba1db',
};