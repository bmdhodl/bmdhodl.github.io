# Gatsby Theme Intro Example

A usage of [gatsby-theme-intro](https://github.com/wkocjan/gatsby-theme-intro) that does nothing but use the theme.
